
    alert('click on name of the country to visit website of respective country');
function pak()
            {
            window.open('https://www.pcb.com.pk','_blank');
            }
function afg()
            {
            window.open('https://cricket.af/member/16','_blank');
            }
function aus()
            {
            window.open('https://www.cricket.com.au/','_blank');
            }
function ban()
            {
            window.open('https://www.tigercricket.com.bd/','_blank');
            }
function eng()
            {
            window.open('https://www.ecb.co.uk/play/find-a-club/','_blank');
            }
function ire()
            {
            window.open('https://cricketireland.ie/','_blank');
            }
function india()
            {
            window.open('https://www.bcci.tv/','_blank');
            }
function newzl()
            {
            window.open('https://www.nzc.nz/','_blank');
            }
function nl()
            {
            window.open('https://www.kncb.nl/en/','_blank');
            }
function sa()
            {
            window.open('https://cricket.co.za/','_blank');
            }
function sri()
            {
            window.open('https://srilankacricket.lk/','_blank');
            }
function sco()
            {
            window.open('https://www.cricketscotland.com/','_blank');
            }
 function west()
            {
            window.open('https://www.windiescricket.com/','_blank');
            }
 function usa()
            {
            window.open('https://usacricket.org/','_blank');
            }
function zim()
            {
            window.open('https://zimcricket.org/','_blank');
            }